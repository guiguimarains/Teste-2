FichaClin — Pacote Completo

Conteúdo:
- fichaclin-source-20250905-194841.zip: código-fonte do app (arquivos principais).
- fichaclin-export-2025-09-05-19-48-41.sql: exportação do banco em SQL (SQLite compatível).
- manifest.json: resumo com tamanhos e datas.

Como usar:
1) Importe o SQL (fichaclin-export-2025-09-05-19-48-41.sql) no seu banco (SQLite/Turso).
2) Coloque os arquivos do código em seu provedor de hospedagem.
3) Ajuste variáveis de ambiente e endpoints conforme necessário.

Gerado em: 2025-09-05T19:48:41.262Z
