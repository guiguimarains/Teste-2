-- FichaClin SQL export
-- Generated at 2025-09-05T19:48:41.262Z
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "User" (
  id TEXT PRIMARY KEY,
  name TEXT,
  handle TEXT,
  image TEXT
);
CREATE TABLE IF NOT EXISTS "Submission" (
  id TEXT PRIMARY KEY,
  userId TEXT,
  status TEXT NOT NULL,
  step INTEGER NOT NULL,
  personal TEXT NOT NULL,
  familyHistory TEXT NOT NULL,
  personalHistory TEXT NOT NULL,
  employers TEXT NOT NULL,
  physicalExam TEXT NOT NULL,
  evolution TEXT NOT NULL,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "Appointment" (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  patient TEXT NOT NULL,
  nomeSocial TEXT,
  cpf TEXT,
  dataNascimento TEXT,
  razaoSocial TEXT,
  cnpj TEXT,
  contact TEXT,
  startAt TEXT NOT NULL,
  durationMins INTEGER NOT NULL,
  status TEXT NOT NULL,
  notes TEXT,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "ServiceRequest" (
  id TEXT PRIMARY KEY,
  empresa TEXT NOT NULL,
  solicitante TEXT NOT NULL,
  paciente TEXT NOT NULL,
  pacienteCpf TEXT,
  motivo TEXT NOT NULL,
  agendadoPara TEXT NOT NULL,
  status TEXT NOT NULL,
  medica TEXT,
  motorista TEXT,
  realizadoEm TEXT,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "Certificate" (
  id TEXT PRIMARY KEY,
  userId TEXT,
  name TEXT NOT NULL,
  fileUrl TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "AsoDocument" (
  id TEXT PRIMARY KEY,
  userId TEXT,
  name TEXT NOT NULL,
  originalUrl TEXT NOT NULL,
  editableUrl TEXT NOT NULL,
  status TEXT NOT NULL,
  fieldsJson TEXT NOT NULL,
  signedUrl TEXT,
  signedAt TEXT,
  certificateId TEXT,
  createdAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_submission_user_status ON "Submission" (userId, status);
CREATE INDEX IF NOT EXISTS idx_submission_created ON "Submission" (createdAt);
CREATE INDEX IF NOT EXISTS idx_appointment_startAt ON "Appointment" (startAt);
CREATE INDEX IF NOT EXISTS idx_sr_status_created ON "ServiceRequest" (status, createdAt);
CREATE INDEX IF NOT EXISTS idx_sr_agendadoPara ON "ServiceRequest" (agendadoPara);
CREATE INDEX IF NOT EXISTS idx_aso_user_created ON "AsoDocument" (userId, createdAt);
CREATE INDEX IF NOT EXISTS idx_aso_certificate ON "AsoDocument" (certificateId);
CREATE INDEX IF NOT EXISTS idx_aso_status ON "AsoDocument" (status);
CREATE INDEX IF NOT EXISTS idx_cert_user_created ON "Certificate" (userId, createdAt);
INSERT INTO "User" (id, name, handle, image) VALUES ('Wp2HtNhZbBHgmqqx', 'Ann.a.delacr.u.z6.7.8', 'annadelacruz678925548080', 'https://adaptive.ai/cdn/f2t3Ykk7F9yhcHTtq93itngQPEmbAi4Q.png');
COMMIT;